/*
 Navicat Premium Data Transfer

 Source Server         : test01
 Source Server Type    : MySQL
 Source Server Version : 80035 (8.0.35)
 Source Host           : localhost:3306
 Source Schema         : studentinfosystem

 Target Server Type    : MySQL
 Target Server Version : 80035 (8.0.35)
 File Encoding         : 65001

 Date: 23/12/2024 19:25:01
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
create database studentinfosystem;
use studentinfosystem;

-- ----------------------------
-- Table structure for classes
-- ----------------------------
DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `grade` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `major` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `counselor` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of classes
-- ----------------------------
INSERT INTO `classes` VALUES (1, '2020', '计算机科学', '李老师');
INSERT INTO `classes` VALUES (2, '2020', '软件工程', '王老师');
INSERT INTO `classes` VALUES (3, '2021', '网络工程', '张老师');
INSERT INTO `classes` VALUES (4, '2019', '数据科学', '刘老师');
INSERT INTO `classes` VALUES (5, '2020', '人工智能', '陈老师');
INSERT INTO `classes` VALUES (6, '2019', '网络安全', '吴老师');
INSERT INTO `classes` VALUES (7, '2021', '大数据', '赵老师');
INSERT INTO `classes` VALUES (8, '2019', '云计算', '孙老师');
INSERT INTO `classes` VALUES (9, '2020', '物联网', '周老师');
INSERT INTO `classes` VALUES (10, '2019', '信息安全', '郑老师');

-- ----------------------------
-- Table structure for hostel
-- ----------------------------
DROP TABLE IF EXISTS `hostel`;
CREATE TABLE `hostel`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `building_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '宿舍楼名称',
  `room_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '房间号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '宿舍信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hostel
-- ----------------------------
INSERT INTO `hostel` VALUES (1, 'A楼', '101');
INSERT INTO `hostel` VALUES (2, 'A楼', '102');
INSERT INTO `hostel` VALUES (3, 'A楼', '103');
INSERT INTO `hostel` VALUES (4, 'A楼', '201');
INSERT INTO `hostel` VALUES (5, 'A楼', '202');
INSERT INTO `hostel` VALUES (6, 'A楼', '203');
INSERT INTO `hostel` VALUES (7, 'A楼', '204');
INSERT INTO `hostel` VALUES (8, 'B楼', '101');
INSERT INTO `hostel` VALUES (9, 'B楼', '102');
INSERT INTO `hostel` VALUES (10, 'B楼', '103');
INSERT INTO `hostel` VALUES (11, 'B楼', '104');
INSERT INTO `hostel` VALUES (12, 'B楼', '201');
INSERT INTO `hostel` VALUES (13, 'B楼', '202');
INSERT INTO `hostel` VALUES (14, 'B楼', '203');
INSERT INTO `hostel` VALUES (15, 'B楼', '204');
INSERT INTO `hostel` VALUES (16, 'C楼', '101');
INSERT INTO `hostel` VALUES (17, 'C楼', '102');
INSERT INTO `hostel` VALUES (18, 'C楼', '103');
INSERT INTO `hostel` VALUES (19, 'C楼', '104');
INSERT INTO `hostel` VALUES (20, 'C楼', '201');
INSERT INTO `hostel` VALUES (21, 'C楼', '202');
INSERT INTO `hostel` VALUES (22, 'C楼', '203');
INSERT INTO `hostel` VALUES (23, 'C楼', '204');

-- ----------------------------
-- Table structure for minority
-- ----------------------------
DROP TABLE IF EXISTS `minority`;
CREATE TABLE `minority`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '民族名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 57 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '民族信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of minority
-- ----------------------------
INSERT INTO `minority` VALUES (1, '汉族');
INSERT INTO `minority` VALUES (2, '蒙古族');
INSERT INTO `minority` VALUES (3, '回族');
INSERT INTO `minority` VALUES (4, '藏族');
INSERT INTO `minority` VALUES (5, '维吾尔族');
INSERT INTO `minority` VALUES (6, '苗族');
INSERT INTO `minority` VALUES (7, '彝族');
INSERT INTO `minority` VALUES (8, '壮族');
INSERT INTO `minority` VALUES (9, '布依族');
INSERT INTO `minority` VALUES (10, '朝鲜族');
INSERT INTO `minority` VALUES (11, '满族');
INSERT INTO `minority` VALUES (12, '侗族');
INSERT INTO `minority` VALUES (13, '瑶族');
INSERT INTO `minority` VALUES (14, '白族');
INSERT INTO `minority` VALUES (15, '土家族');
INSERT INTO `minority` VALUES (16, '哈尼族');
INSERT INTO `minority` VALUES (17, '哈萨克族');
INSERT INTO `minority` VALUES (18, '傣族');
INSERT INTO `minority` VALUES (19, '黎族');
INSERT INTO `minority` VALUES (20, '傈僳族');
INSERT INTO `minority` VALUES (21, '佤族');
INSERT INTO `minority` VALUES (22, '畲族');
INSERT INTO `minority` VALUES (23, '高山族');
INSERT INTO `minority` VALUES (24, '拉祜族');
INSERT INTO `minority` VALUES (25, '水族');
INSERT INTO `minority` VALUES (26, '东乡族');
INSERT INTO `minority` VALUES (27, '纳西族');
INSERT INTO `minority` VALUES (28, '景颇族');
INSERT INTO `minority` VALUES (29, '柯尔克孜族');
INSERT INTO `minority` VALUES (30, '土族');
INSERT INTO `minority` VALUES (31, '达斡尔族');
INSERT INTO `minority` VALUES (32, '仡佬族');
INSERT INTO `minority` VALUES (33, '乌孜别克族');
INSERT INTO `minority` VALUES (34, '俄罗斯族');
INSERT INTO `minority` VALUES (35, '鄂温克族');
INSERT INTO `minority` VALUES (36, '德昂族');
INSERT INTO `minority` VALUES (37, '保安族');
INSERT INTO `minority` VALUES (38, '裕固族');
INSERT INTO `minority` VALUES (39, '京族');
INSERT INTO `minority` VALUES (40, '塔吉克族');
INSERT INTO `minority` VALUES (41, '独龙族');
INSERT INTO `minority` VALUES (42, '鄂伦春族');
INSERT INTO `minority` VALUES (43, '赫哲族');
INSERT INTO `minority` VALUES (44, '门巴族');
INSERT INTO `minority` VALUES (45, '珞巴族');
INSERT INTO `minority` VALUES (46, '基诺族');
INSERT INTO `minority` VALUES (47, '朝鲜族');
INSERT INTO `minority` VALUES (48, '黎族');
INSERT INTO `minority` VALUES (49, '哈尼族');
INSERT INTO `minority` VALUES (50, '壮族');
INSERT INTO `minority` VALUES (51, '蒙古族');
INSERT INTO `minority` VALUES (52, '藏族');
INSERT INTO `minority` VALUES (53, '回族');
INSERT INTO `minority` VALUES (54, '维吾尔族');
INSERT INTO `minority` VALUES (55, '彝族');
INSERT INTO `minority` VALUES (56, '土家族');

-- ----------------------------
-- Table structure for schools
-- ----------------------------
DROP TABLE IF EXISTS `schools`;
CREATE TABLE `schools`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `founding_date` date NOT NULL,
  `address` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  CONSTRAINT `schools_chk_1` CHECK (`status` in (0,1))
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of schools
-- ----------------------------
INSERT INTO `schools` VALUES (1, '北京科技大学', '1988-09-01', '北京市海淀区', '010-88888888', 1);
INSERT INTO `schools` VALUES (2, '清华大学', '1911-04-01', '北京市海淀区', '010-62771010', 1);
INSERT INTO `schools` VALUES (3, '北京大学', '1898-06-01', '北京市海淀区', '010-62751407', 1);
INSERT INTO `schools` VALUES (4, '上海交通大学', '1896-07-01', '上海市闵行区', '021-54742222', 1);
INSERT INTO `schools` VALUES (5, '浙江大学', '1897-07-01', '浙江省杭州市', '0571-87951660', 1);
INSERT INTO `schools` VALUES (6, '复旦大学', '1905-10-01', '上海市杨浦区', '021-65642222', 1);
INSERT INTO `schools` VALUES (7, '南京大学', '1902-10-01', '江苏省南京市', '025-83592316', 1);
INSERT INTO `schools` VALUES (8, '武汉大学', '1893-02-01', '湖北省武汉市', '027-68756110', 1);
INSERT INTO `schools` VALUES (9, '四川大学', '1896-01-01', '四川省成都市', '028-85412821', 1);
INSERT INTO `schools` VALUES (10, '中山大学', '1924-04-01', '广东省广州市', '020-84112253', 1);

-- ----------------------------
-- Table structure for stu_minority_hostel
-- ----------------------------
DROP TABLE IF EXISTS `stu_minority_hostel`;
CREATE TABLE `stu_minority_hostel`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL COMMENT '学生ID',
  `minority_id` int NOT NULL COMMENT '民族ID',
  `hostel_id` int NOT NULL COMMENT '宿舍ID',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_student_id`(`student_id` ASC) USING BTREE,
  INDEX `idx_minority_id`(`minority_id` ASC) USING BTREE,
  INDEX `idx_hostel_id`(`hostel_id` ASC) USING BTREE,
  CONSTRAINT `fk_hostel` FOREIGN KEY (`hostel_id`) REFERENCES `hostel` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_minority` FOREIGN KEY (`minority_id`) REFERENCES `minority` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '学生-民族-宿舍关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of stu_minority_hostel
-- ----------------------------
INSERT INTO `stu_minority_hostel` VALUES (1, 1, 1, 1);
INSERT INTO `stu_minority_hostel` VALUES (2, 3, 3, 8);
INSERT INTO `stu_minority_hostel` VALUES (3, 4, 2, 15);
INSERT INTO `stu_minority_hostel` VALUES (4, 5, 4, 16);
INSERT INTO `stu_minority_hostel` VALUES (5, 7, 8, 20);
INSERT INTO `stu_minority_hostel` VALUES (6, 8, 10, 23);

-- ----------------------------
-- Table structure for students
-- ----------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_card` char(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `major` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `study_system` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `admission_date` date NOT NULL,
  `graduation_date` date NOT NULL,
  `class_name` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `counselor` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
	
  `status` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  CONSTRAINT `students_chk_1` CHECK (length(`id_card`) = 18),
  CONSTRAINT `students_chk_2` CHECK (`status` in (0,1))
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of students
-- ----------------------------
INSERT INTO `students` VALUES (1, '小明', '20', '男', '110101200001015678', '北京市海淀区', '计算机科学', '全日制', '2020-09-01', '2024-06-30', '计算机2001', '李老师',  1);
INSERT INTO `students` VALUES (3, '小李', '19', '男', '110101200001035678', '广州市天河区', '网络工程', '全日制', '2021-09-01', '2025-06-30', '网络2001', '张老师',  1);
INSERT INTO `students` VALUES (4, '张三', '20', '男', '110101200001011234', '北京市朝阳区XX街道1号', '计算机科学与技术', '全日制', '2022-09-01', '2026-06-30', '计算机专业一班', '王老师',  1);
INSERT INTO `students` VALUES (5, '小王', '20', '男', '110101200001055678', '杭州市西湖区', '人工智能', '全日制', '2020-09-01', '2024-06-30', '人工智能2001', '陈老师', 1);
INSERT INTO `students` VALUES (7, '小刘', '19', '男', '110101200001075678', '武汉市洪山区', '大数据', '全日制', '2021-09-01', '2025-06-30', '大数据2001', '赵老师', 0);
INSERT INTO `students` VALUES (8, '小林', '22', '女', '110101200001085678', '重庆市渝中区', '云计算', '全日制', '2019-09-01', '2023-06-30', '云计算2001', '孙老师', 1);

-- ----------------------------
-- Table structure for teachers
-- ----------------------------
DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` char(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_card` char(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `major` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_date` date NOT NULL,
  `class_name` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dormitory` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  CONSTRAINT `teachers_chk_1` CHECK (length(`contact`) = 11),
  CONSTRAINT `teachers_chk_2` CHECK (length(`id_card`) = 18),
  CONSTRAINT `teachers_chk_3` CHECK (`status` in (0,1))
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of teachers
-- ----------------------------
INSERT INTO `teachers` VALUES (3, 'T003', '李四', '20', '男', '15712345678', '110101197503035678', '北京市朝阳区某某路2号', '软件工程', '2015-09-01', '网络2001', '6号楼-203', 1);
INSERT INTO `teachers` VALUES (4, 'T001', '张师', '36', '男', '13812345678', '110101198801011234', '北京市朝阳区新街口1号', '计算机科学与技术', '2015-08-15', '计算机专业一班', '教学楼2号宿舍', 1);
INSERT INTO `teachers` VALUES (5, 'T005', '陈老师', '38', '女', '15912345678', '110101197505055678', '杭州市西湖区', '人工智能', '2012-09-01', '人工智能2001', '教工5号楼', 1);
INSERT INTO `teachers` VALUES (6, 'T006', '吴老师', '42', '男', '16012345678', '110101197506065678', '成都市高新区', '网络安全', '2007-09-01', '网络安全2001', '教工6号楼', 1);
INSERT INTO `teachers` VALUES (7, 'T007', '赵老师', '36', '女', '16112345678', '110101197507075678', '武汉市洪山区', '大数据', '2014-09-01', '大数据2001', '教工7号楼', 0);
INSERT INTO `teachers` VALUES (9, 'T009', '周老师', '37', '女', '16312345678', '110101197509095678', '西安市碑林区', '物联网', '2013-09-01', '物联网2001', '教工9号楼', 1);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` char(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL DEFAULT 1,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://big-001event.oss-cn-beijing.aliyuncs.com/51dc7a1a-b873-476a-9f1e-9531931120e5.jpg',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_account_unique`(`account` ASC) USING BTREE,
  CONSTRAINT `users_chk_1` CHECK (length(`phone`) = 11),
  CONSTRAINT `users_chk_2` CHECK (`status` in (0,1))
) ENGINE = InnoDB AUTO_INCREMENT = 828502066 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (828502040, 's', '14523655442', 'zhouba1', 'c09be5f53ffb34196a8d97800821c241', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/7f8fe843-0538-405e-8d5f-e85fa0bffb3b.jpg');
INSERT INTO `users` VALUES (828502044, '477', '17456366554', 'fg', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/16a2eeba-8aff-427d-a2ea-3526a6b05704.jpg');
INSERT INTO `users` VALUES (828502045, 'sd', '14563233447', '123', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/c8363927-1407-4b25-bef3-b388b6d57691.jpg');
INSERT INTO `users` VALUES (828502046, 'qwe', '17856322445', 'qwer', 'a800eebe923dc014ee5410e5e71aebaf', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/7d6e4f2e-9d96-4420-86fb-8d8dc2940591.jpg');
INSERT INTO `users` VALUES (828502047, 'sunqiaa1', '17845633554', 'qweas', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/17b9b13e-5cc9-4225-90c6-8a8121b5388c.jpg');
INSERT INTO `users` VALUES (828502054, 'sds', '17845633554', 'zhouba1sd', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/a2697fad-19ac-4aa3-88e1-b7d00899da94.jpg');
INSERT INTO `users` VALUES (828502055, 'sd', '17856322550', 'szwww', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/eb22ac14-35c7-4382-b5b5-55412db84aac.jpg');
INSERT INTO `users` VALUES (828502060, 'shizhiwei', '17842377220', 'shizhiwei', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/b16863ef-7997-4593-8faf-246f31217e3f.jpg');
INSERT INTO `users` VALUES (828502064, 'duanshiyun', '15654566332', 'duanshiyun', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/1014f362-650a-4127-b10d-f46e603cf23f.jpg');
INSERT INTO `users` VALUES (828502065, 'dongyuandong', '17545633554', 'dongyuandong', '3d7dd7b26500bd0595573b651d0080fd', 1, 'https://big-001event.oss-cn-beijing.aliyuncs.com/25f1f65c-d106-4700-8ce0-a39bc420d811.jpg');

SET FOREIGN_KEY_CHECKS = 1;
