package com.example.liekai.service;

import com.example.liekai.pojo.Hostel;
import com.example.liekai.pojo.Minority;
import com.example.liekai.pojo.Student;

import java.util.List;
import java.util.Map;

public interface StudentService {
    void deleteStudent(Integer id);
/*
* 查找学生
* */
    List<Student> list();

    Student createStudent(Student student);

    Student updateStudent(Student student);

    List<Map<String, Object>> queryByMinority(String minorityName);

    List<Map<String, Object>> queryByHostel(Integer hostelId);

    List<Map<String, Object>> queryHostelByMinority(String minorityName);

    List<Hostel> getHostelList();

    List<Minority> getMinorityList();
}
