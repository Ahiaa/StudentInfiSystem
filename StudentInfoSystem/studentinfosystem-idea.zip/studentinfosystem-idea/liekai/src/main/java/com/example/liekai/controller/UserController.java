package com.example.liekai.controller;


import com.example.liekai.pojo.PageBean;
import com.example.liekai.pojo.Result;
import com.example.liekai.pojo.User;
import com.example.liekai.service.UserService;
import com.example.liekai.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", maxAge = 3600)
// 用户控制器 包含responsebody(将返回数据转为json)
@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
/*
* 删除用户
*
*
* */
@DeleteMapping("/{id}")
//    @PathVariableJ接受路径参数绑定到id
public Result deleteUser(@PathVariable Integer id) {
    userService.deleteUser(id);
    return Result.success();
}
/*
* 查询用户
* */
    @GetMapping
    public Result list(){
        List<User> userList=userService.list();
        return Result.success(userList);
    }
    /*
    * 新增用户
    * */
    @PostMapping("/register")
//    @RequestBody服务端接受前端传来的json 封装到实体类中
    public Result createUser(@RequestBody User user) {
//        User createdUser = userService.createUser(user);
//        return Result.success(createdUser);
        Boolean bo= userService.createUser(user);
            return bo? Result.success("注册成功"):Result.error("注册失败！账号已被占用");
    }

    /*
    * 更新用户信息
    * */
    // 更新用户信息
    @PutMapping("/{id}")
    public Result updateUser(
            @PathVariable Integer id,
            @RequestBody User user
    ) {
        user.setId(id);
        User updatedUser = userService.updateUser(user);
        return Result.success(updatedUser);
    }
/*
* 登陆
* */
    @PostMapping("/login")
    public Result login(@RequestBody User user){
        User u=userService.login(user);
        /*
        * 登陆成功·生成 下发令牌
        *
        * */
        if(u!=null){
            Map<String, Object> claims=new HashMap<>();
            claims.put("id",u.getId());
            claims.put("name",u.getName());
            claims.put("account",u.getAccount());
           String jwt= JwtUtils.generateJwt(claims);
           return Result.success(jwt);
        }
        return Result.error("用户名或者密码错误");
    }

@GetMapping("/page")
public Result page(@RequestParam(defaultValue = "1") Integer currentPage,
                   @RequestParam(defaultValue = "10") Integer pageSize,
                   @RequestParam(required=false) String name,
                   @RequestParam(required=false)String phone ,
                   @RequestParam(required=false)Integer status
) {
    PageBean pageBean=userService.page(currentPage,pageSize,name,phone,status);
    return  Result.success(pageBean);
}
}
