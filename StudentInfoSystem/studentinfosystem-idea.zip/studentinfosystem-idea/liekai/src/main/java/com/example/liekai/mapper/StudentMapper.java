package com.example.liekai.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liekai.pojo.Hostel;
import com.example.liekai.pojo.Minority;
import com.example.liekai.pojo.Student;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface StudentMapper extends BaseMapper<Student> {
    /*
    * 根据名族查学生
    * */
    @Select("SELECT * FROM students s " +
            "JOIN stu_minority_hostel smh ON s.id = smh.student_id " +
            "JOIN minority m ON m.id = smh.minority_id " +
            "WHERE m.name = #{minorityName}")
    List<Map<String, Object>> queryByMinority(String minorityName);
///*根据宿舍查学生*/
//    SELECT s.name, h.building_name, h.room_number
    @Select("SELECT * " +
            "FROM students s " +
            "JOIN stu_minority_hostel smh ON s.id = smh.student_id " +
            "JOIN hostel h ON h.id = smh.hostel_id " +
            "WHERE h.id = #{hostelId}")
    List<Map<String, Object>> queryByHostel(Integer hostelId);
/*根据名族查宿舍*/
    @Select("SELECT h.building_name, h.room_number, m.name as minority_name " +
            "FROM hostel h " +
            "JOIN stu_minority_hostel smh ON h.id = smh.hostel_id " +
            "JOIN minority m ON m.id = smh.minority_id " +
            "WHERE m.name = #{minorityName}")
    List<Map<String, Object>> queryHostelByMinority(String minorityName);

/*信息回显*/
    @Select("select * from hostel")
    List<Hostel> selectHostelList();
@Select("select * from minority")
    List<Minority> selectMinorityList();
}
