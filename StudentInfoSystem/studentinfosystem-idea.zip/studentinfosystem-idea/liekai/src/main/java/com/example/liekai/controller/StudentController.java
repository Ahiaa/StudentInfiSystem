package com.example.liekai.controller;

import com.example.liekai.pojo.Hostel;
import com.example.liekai.pojo.Minority;
import com.example.liekai.pojo.Result;
import com.example.liekai.pojo.Student;
import com.example.liekai.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/students")
public class StudentController {
    @Autowired
    private StudentService studentService;
    /*
    * 删除学生
    * */
    @DeleteMapping("/{id}")
    public Result deleteStudent(@PathVariable Integer id) {
        studentService.deleteStudent(id);
        return Result.success();
    }
    /*
    * 查询学生
    * */
    @GetMapping
    public Result list(){
        List<Student> studentList=studentService.list();
        return Result.success(studentList);
    }
    /*
    * 新增学生
    * */
    @PostMapping
    public Result createStudent(@RequestBody Student student) {
        Student createdStudent = studentService.createStudent(student);
        return Result.success(createdStudent);
    }
/*
* 更新学生信息
* */
// 更新学生信息
@PutMapping("/{id}")
public Result updateStudent(
        @PathVariable Integer id,
        @RequestBody Student student
) {
    student.setId(id);
    Student updatedStudent = studentService.updateStudent(student);
    return Result.success(updatedStudent);
}
/*
//*-- 根据宿舍查学生：
* */

    @GetMapping("/queryByHostel/{hostelId}")
    public Result queryByHostel(@PathVariable Integer hostelId) {
        List<Map<String, Object>> result = studentService.queryByHostel(hostelId);
        return Result.success(result);
    }

/*
* -- 根据民族查学生：
* */

    @GetMapping("/queryByMinority/{minorityName}")
    public Result queryByMinority(@PathVariable String minorityName) {
        List<Map<String, Object>> result = studentService.queryByMinority(minorityName);
        return Result.success(result);
    }
    /*
     *-- 根据民族查宿舍
     * */

    @GetMapping("/queryHostelByMinority/{minorityName}")
    public Result queryHostelByMinority(@PathVariable String minorityName) {
        List<Map<String, Object>> result = studentService.queryHostelByMinority(minorityName);
        return Result.success(result);
    }
    /*
    * 民族 班级信息回显
    * */

        @GetMapping("/hostelList")
        public Result getHostelList() {
            List<Hostel> hostelList = studentService.getHostelList();
            return Result.success(hostelList);
        }

        @GetMapping("/minorityList")
        public Result getMinorityList() {
            List<Minority> minorityList = studentService.getMinorityList();
            return Result.success(minorityList);
        }
    }

