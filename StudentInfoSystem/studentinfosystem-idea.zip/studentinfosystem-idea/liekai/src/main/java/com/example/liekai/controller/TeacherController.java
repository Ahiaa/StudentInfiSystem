package com.example.liekai.controller;

import com.example.liekai.pojo.Result;
import com.example.liekai.pojo.Teacher;
import com.example.liekai.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/teachers")
public class TeacherController {
    @Autowired
    private TeacherService teacherService;
    /*
    * 删除教师
    * */
    @DeleteMapping("/{id}")
    public Result deleteTeacher(@PathVariable Integer id) {
        teacherService.deleteTeacher(id);
        return Result.success();
    }

    /*
    * 查询教师
    * */
    @GetMapping
    public Result list(){
        List<Teacher> teacherList=teacherService.list();
        return Result.success(teacherList);
    }
    /*
    * 新增教师
    * */
    @PostMapping
    public Result createTeacher(@RequestBody Teacher teacher) {
        System.out.println("@@@@"+teacher);

        Teacher createdTeacher = teacherService.createTeacher(teacher);
        return Result.success(createdTeacher);
    }
    /*
    * 修改教师
    * */
    @PutMapping("/{id}")
    public Result updateTeacher(
            @PathVariable Integer id,
            @RequestBody Teacher teacher
    ) {
        teacher.setId(id);
        Teacher updatedTeacher = teacherService.updateTeacher(teacher);
        return Result.success(updatedTeacher);
    }
}
