package com.example.liekai.service.Impl;

import com.example.liekai.mapper.TeacherMapper;
import com.example.liekai.pojo.Teacher;
import com.example.liekai.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService {
    @Autowired
    private TeacherMapper teacherMapper;
/*
* 查询老师
* */
    @Override
    public List<Teacher> list() {
        return teacherMapper.selectList(null);
    }

    @Override
    public void deleteTeacher(Integer id) {
        teacherMapper.deleteById(id);
    }

    @Override
    public Teacher createTeacher(Teacher teacher) {
        teacherMapper.insert(teacher);
        return teacher;
    }

    @Override
    public Teacher updateTeacher(Teacher teacher) {
        teacherMapper.updateById(teacher);
        return teacher;
    }
}
