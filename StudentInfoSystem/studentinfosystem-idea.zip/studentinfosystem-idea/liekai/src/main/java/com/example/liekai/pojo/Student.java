package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

// 学生实体类
@TableName("students")
public class Student {
    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;
    private String name;
    private String age;
    private String gender;
//    @TableField("id_card")
    private String idCard;
    private String address;
    private String major;
//    @TableField("study_system")
    private String studySystem;
//    @TableField("admission_date")
    private Date admissionDate;
//    @TableField("graduation_date")
@JsonFormat(pattern = "yyyy-MM-dd")
    private Date graduationDate;
//    @TableField("class_name")
    private String className;
    private String counselor;
    private Integer status;

    // 无参构造方法
    public Student() {}

    // 全参构造方法
    public Student(Integer id, String name, String age, String gender,
                   String idCard, String address, String major,
                   String studySystem, Date admissionDate, Date graduationDate,
                   String className, String counselor,
                   Integer status) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.idCard = idCard;
        this.address = address;
        this.major = major;
        this.studySystem = studySystem;
        this.admissionDate = admissionDate;
        this.graduationDate = graduationDate;
        this.className = className;
        this.counselor = counselor;
        this.status = status;
    }

    // Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getStudySystem() {
        return studySystem;
    }

    public void setStudySystem(String studySystem) {
        this.studySystem = studySystem;
    }

    public Date getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(Date admissionDate) {
        this.admissionDate = admissionDate;
    }

    public Date getGraduationDate() {
        return graduationDate;
    }

    public void setGraduationDate(Date graduationDate) {
        this.graduationDate = graduationDate;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getCounselor() {
        return counselor;
    }

    public void setCounselor(String counselor) {
        this.counselor = counselor;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age='" + age + '\'' +
                ", gender='" + gender + '\'' +
                ", idCard='" + idCard + '\'' +
                ", address='" + address + '\'' +
                ", major='" + major + '\'' +
                ", studySystem='" + studySystem + '\'' +
                ", admissionDate=" + admissionDate +
                ", graduationDate=" + graduationDate +
                ", className='" + className + '\'' +
                ", counselor='" + counselor + '\'' +
                ", dormitory='" +
                ", status=" + status +
                '}';
    }
}
