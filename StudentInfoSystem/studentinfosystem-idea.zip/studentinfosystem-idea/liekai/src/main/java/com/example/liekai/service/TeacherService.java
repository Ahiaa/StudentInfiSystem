package com.example.liekai.service;

import com.example.liekai.pojo.Teacher;

import java.util.List;

public interface TeacherService {

     List<Teacher> list() ;

    void deleteTeacher(Integer id);

    Teacher createTeacher(Teacher teacher);

    Teacher updateTeacher(Teacher teacher);
}
