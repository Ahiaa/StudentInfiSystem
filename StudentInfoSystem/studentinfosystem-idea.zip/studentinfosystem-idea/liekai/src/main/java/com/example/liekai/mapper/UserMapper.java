package com.example.liekai.mapper;


//import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liekai.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    /*
    * 自定义登陆功能
    * */
//@Select("select * from users where account=#{account} && password=#{password}")
    @Select("select password from users where account=#{account}")
    User getByAccountAndPassword(String user);


    List<User> selectLists(String name, String phone, Integer status);
}
