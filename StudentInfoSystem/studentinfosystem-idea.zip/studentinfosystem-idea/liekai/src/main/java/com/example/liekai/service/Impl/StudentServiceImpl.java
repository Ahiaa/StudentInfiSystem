package com.example.liekai.service.Impl;

import com.example.liekai.mapper.StudentMapper;
import com.example.liekai.pojo.Hostel;
import com.example.liekai.pojo.Minority;
import com.example.liekai.pojo.Student;
import com.example.liekai.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentMapper studentMapper;
    @Override
    public void deleteStudent(Integer id) {
        studentMapper.deleteById(id);
    }
/*
* 查找学生
* */
    @Override
    public List<Student> list() {
        return studentMapper.selectList(null);
    }
/*
* 新增学生
* */
    @Override
    public Student createStudent(Student student) {
        studentMapper.insert(student);
        return student;
    }

    @Override
    public Student updateStudent(Student student) {
        studentMapper.updateById(student);
        return student;
    }
/*
* 根据民族查询学生
* */
    @Override
    public List<Map<String, Object>> queryByMinority(String minorityName) {
        return studentMapper.queryByMinority(minorityName);
    }
/*根据根据宿舍查学生*/
    @Override
    public List<Map<String, Object>> queryByHostel(Integer hostelId) {
        return studentMapper.queryByHostel(hostelId);
    }

    @Override
    public List<Map<String, Object>> queryHostelByMinority(String minorityName) {
        return studentMapper.queryHostelByMinority(minorityName);
    }
/*
* 查询回显
* */
    @Override
    public List<Hostel> getHostelList() {
        return studentMapper.selectHostelList();
    }

    @Override
    public List<Minority> getMinorityList() {
        return studentMapper.selectMinorityList();
    }
}
