package com.example.liekai.service.Impl;

import org.springframework.stereotype.Service;

@Service
public class ClassServiceImpl {
}
