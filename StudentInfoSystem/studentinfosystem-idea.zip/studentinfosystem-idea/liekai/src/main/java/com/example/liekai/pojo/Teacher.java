package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

// 教师实体类
@TableName("teachers")
public class Teacher {
    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;
    @TableField("employee_id")
    private String employeeId;
    private String name;
    private String age;
    private String gender;
    private String contact;
    @TableField("id_card")
    private String idCard;
    private String address;
    private String major;
    @TableField("entry_date")
    private Date entryDate;
    @TableField("class_name")
    private String className;
    private String dormitory;
    private Integer status;

    // 无参构造方法
    public Teacher() {}

    // 全参构造方法
    public Teacher(Integer id, String employeeId, String name, String age,
                   String gender, String contact, String idCard, String address,
                   String major, Date entryDate, String className,
                   String dormitory, Integer status) {
        this.id = id;
        this.employeeId = employeeId;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.contact = contact;
        this.idCard = idCard;
        this.address = address;
        this.major = major;
        this.entryDate = entryDate;
        this.className = className;
        this.dormitory = dormitory;
        this.status = status;
    }

    // Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getDormitory() {
        return dormitory;
    }

    public void setDormitory(String dormitory) {
        this.dormitory = dormitory;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "id=" + id +
                ", employeeId='" + employeeId + '\'' +
                ", name='" + name + '\'' +
                ", age='" + age + '\'' +
                ", gender='" + gender + '\'' +
                ", contact='" + contact + '\'' +
                ", idCard='" + idCard + '\'' +
                ", address='" + address + '\'' +
                ", major='" + major + '\'' +
                ", entryDate=" + entryDate +
                ", className='" + className + '\'' +
                ", dormitory='" + dormitory + '\'' +
                ", status=" + status +
                '}';
    }
}

