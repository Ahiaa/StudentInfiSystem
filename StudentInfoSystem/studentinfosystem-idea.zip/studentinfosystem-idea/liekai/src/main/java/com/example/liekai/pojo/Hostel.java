package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.TableName;

@TableName("hostel")
public class Hostel {
    private Integer id;
    private String buildingName;    // 宿舍楼名称
    private String roomNumber;      // 房间号

    public Hostel() {
    }

    public Hostel(Integer id, String buildingName, String roomNumber) {
        this.id = id;
        this.buildingName = buildingName;
        this.roomNumber = roomNumber;
    }

    // getter和setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
}
