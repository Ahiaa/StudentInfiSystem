package com.example.liekai.service.Impl;


import com.example.liekai.mapper.UserMapper;
import com.example.liekai.pojo.PageBean;
import com.example.liekai.pojo.User;
import com.example.liekai.service.UserService;
import com.example.liekai.utils.Md5Util;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

// 用户服务实现
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    /*
     * 删除
     * */
    @Override
    public void deleteUser(Integer id) {
        userMapper.deleteById(id);
    }

    @Override
    public List<User> list() {
//        return userMapper.selectList(null);
        return userMapper.selectList(null);
    }

    /*
     *
     * 新增用户*/
    @Override
    public Boolean createUser(User user) {
//         userMapper.insert(user);
//         return user;
        List<User> users = userMapper.selectList(null);
        for (User userAlll : users) {
            /*账户重复*/
            if (user.getAccount() == userAlll.getAccount()) {
                return false;
            }
        }
        //密码md5加密
        String password = Md5Util.getMD5(user.getPassword());
        user.setPassword(password);
        userMapper.insert(user);
        return true;
    }


    @Override
    public User updateUser(User user) {
        userMapper.updateById(user);
        return user;
    }

    /*
     * 用户登陆
     * */
    @Override
    public User login(User user) {
//            // 1. 先根据account查询用户
//            User dbUser = userMapper.getByAccountAndPassword(user.getAccount());
//            // 2. 用户不存在，返回null
//            if(dbUser == null) {
//                return null;
//            }
//            // 3. 将前端传来的密码进行MD5加密
//            String inputPassword = Md5Util.getMD5(user.getPassword());
//
//            // 4. 比对加密后的密码是否与数据库中的密码一致
//            if(inputPassword.equals(dbUser.getPassword())) {
//                // 密码正确，返回用户信息
//                return dbUser;
//            }
//            // 5. 密码不正确，返回null
//            return null;
//        }
        String password = Md5Util.getMD5(user.getPassword());
        /*数据库拿到的passord*/
        User user1 = userMapper.getByAccountAndPassword(user.getAccount());
        if (user1 != null) {
            return password.equals(user1.getPassword()) ? user1 : null;
        }
        return null;
    }

    @Override
    public PageBean page(Integer currentPage, Integer pageSize,String name,String phone ,Integer status) {
        PageHelper.startPage(currentPage,pageSize);
//        List<User> userList= userMapper.selectList(null);
        List<User> userList= userMapper.selectLists(name,phone,status);
        Page<User> u= (Page<User>)userList;
        PageBean pageBean = new PageBean(u.getTotal(), u.getResult());
        return pageBean;
    }


}
