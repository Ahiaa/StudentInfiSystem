package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("stu_minority_hostel")
public class StuMinorityHostel {
    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;
    private Integer studentId;      // 学生ID
    private Integer minorityId;     // 民族ID
    private Integer hostelId;       // 宿舍ID

    public StuMinorityHostel() {
    }

    public StuMinorityHostel(Integer id, Integer studentId, Integer minorityId, Integer hostelId) {
        this.id = id;
        this.studentId = studentId;
        this.minorityId = minorityId;
        this.hostelId = hostelId;
    }

    // getter和setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getMinorityId() {
        return minorityId;
    }

    public void setMinorityId(Integer minorityId) {
        this.minorityId = minorityId;
    }

    public Integer getHostelId() {
        return hostelId;
    }

    public void setHostelId(Integer hostelId) {
        this.hostelId = hostelId;
    }
}
