package com.example.liekai.service;


import com.example.liekai.pojo.PageBean;
import com.example.liekai.pojo.User;

import java.util.List;

// 用户服务接口
public interface UserService {

    void deleteUser(Integer id);

    List<User> list();

    Boolean createUser(User user);

    User updateUser(User user);

    User login(User user);

    PageBean page(Integer currentPage, Integer pageSize,String name,String phone ,Integer status);
}
