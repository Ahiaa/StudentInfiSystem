package com.example.liekai.pojo;

import com.baomidou.mybatisplus.annotation.TableName;

// 班级实体类
@TableName("classes")
public class Classes {
    private Integer id;
    private String grade;
    private String major;
    private String counselor;

    // 无参构造方法
    public Classes() {}

    // 全参构造方法
    public Classes(Integer id, String grade, String major, String counselor) {
        this.id = id;
        this.grade = grade;
        this.major = major;
        this.counselor = counselor;
    }

    // Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getCounselor() {
        return counselor;
    }

    public void setCounselor(String counselor) {
        this.counselor = counselor;
    }
}
