package com.example.liekai;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.annotation.MapperScan;

import java.util.Date;
import java.util.HashMap;

//@SpringBootTest
@MapperScan("com.baomidou.mybatisplus.samples.quickstart.mapper")
class LiekaiApplicationTests {

    @Test
    /*
    * 测试jwt令牌
    * */
    void contextLoads() {
        HashMap<String, Object> claims = new HashMap<>();
        claims.put("id",1);
        claims.put("name","tom");

       String jwt= Jwts.builder()
                .signWith(SignatureAlgorithm.HS256,"hello")/*自定义算法*/
                .setClaims(claims)
    /*自定义数据*/
                .setExpiration(new Date(System.currentTimeMillis()+3600*1000))
                .compact();/*拿到生成的Jwt令牌*/
        System.out.println(jwt);
    }

}
