import './styles/main.scss'

import { createApp } from 'vue'
import { createPinia } from 'pinia'
import ElementpPlus from 'element-plus'
// 导入elementPlus中文包
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import { createPersistedState } from 'pinia-persistedstate-plugin'
import 'element-plus/dist/index.css'
import App from './App.vue'
import router from './router/index.js'
// 引入路由守卫
import '@/router/permission.js'

const app = createApp(App)
app.use(ElementpPlus,{locale:zhCn})
const pinia=createPinia()
pinia.use(createPersistedState())
app.use(pinia)
app.use(router)

app.mount('#app')
