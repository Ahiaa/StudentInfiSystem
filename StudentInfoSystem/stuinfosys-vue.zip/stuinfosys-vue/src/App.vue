<template>
<!-- <user-avtar></user-avtar> -->

  <!-- components: { UserAvtar }, -->
 <router-view></router-view>
</template>

<script setup>
import UserAvtar from './views/user/UserAvtar.vue';


</script>

<style >

</style>