<template>
  <!-- 头部 -->
  <div class="page-container">
    <div class="header">
      <span class="title">用户管理</span>
      <el-button
        type="primary"
        class="add-button"
        :icon="Plus"
        @click="handleAdd"
      >
        添加用户
      </el-button>
    </div>

    <!-- 搜索框 -->
    <div class="search-form">
      <el-form :inline="true" :model="searchForm" class="form-content">
        <el-form-item label="姓名">
          <el-input
            v-model="searchForm.name"
            placeholder="请输入姓名"
            clearable
          />
        </el-form-item>
        <el-form-item label="电话">
          <el-input
            v-model="searchForm.phone"
            placeholder="请输入电话"
            clearable
          />
        </el-form-item>
        <el-form-item label="状态">
          <el-select
            v-model="searchForm.status"
            placeholder="请选择状态"
            clearable
          >
            <el-option label="启用" :value="1" />
            <el-option label="禁用" :value="0" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSearch" :icon="Search"
            >搜索</el-button
          >
          <el-button @click="onReset" :icon="Refresh">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 表格 -->
    <div class="table-container">
      <el-table :data="tableData" style="width: 100%" :border="true" stripe>
        <!-- 头像列 - 固定宽度 -->
        <el-table-column label="头像" width="120" align="center">
          <template #default="scope">
            <el-avatar :size="50" :src="scope.row.image" />
          </template>
        </el-table-column>

        <!-- 其他列使用相同的宽度比例 -->
        <el-table-column
          prop="name"
          label="姓名"
          min-width="160"
          align="center"
        />
        <el-table-column
          prop="phone"
          label="电话"
          min-width="160"
          align="center"
        />
        <el-table-column
          prop="account"
          label="账号"
          min-width="160"
          align="center"
        />

        <!-- 状态列 - 固定宽度因为内容较短 -->
        <el-table-column prop="status" label="状态" width="120" align="center">
          <template #default="scope">
            <el-tag :type="scope.row.status === 1 ? 'success' : 'danger'">
              {{ scope.row.status === 1 ? "启用" : "禁用" }}
            </el-tag>
          </template>
        </el-table-column>

        <!-- 操作列 - 固定宽度且固定在右侧 -->
        <el-table-column label="操作" width="170" fixed="right" align="center">
          <template #default="{ row }">
            <el-button
              type="primary"
              :icon="Edit"
              circle
              class="action-button"
              @click="handleEdit(row)"
            />
            <el-button
              type="danger"
              @click="deleteUser(row)"
              :icon="Delete"
              circle
              class="action-button"
            />
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pagination-container">
      <el-pagination
        v-model:current-page="pagination.currentPage"
        v-model:page-size="pagination.pageSize"
        :page-sizes="[5, 10, 20]"
        :total="pagination.total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
    <!-- 用户对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '添加用户' : '编辑用户'"
      width="500px"
      :close-on-click-modal="false"
    >
      <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" placeholder="请输入姓名" />
        </el-form-item>
        <el-form-item label="电话" prop="phone">
          <el-input v-model="form.phone" placeholder="请输入电话" />
        </el-form-item>

        <el-form-item label="头像" prop="image">
          <el-upload
            class="avatar-uploader"
            action="/api/upload"
            name="image"
            :show-file-list="false"
            :headers="{ token: tokenStore.token }"
            :on-success="uploadSuccess"
            :on-error="uploadError"
            :before-upload="beforeAvatarUpload"
          >
            <img v-if="form.image" :src="form.image" class="avatar-preview" />

            <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
          </el-upload>
        </el-form-item>

        <el-form-item label="账号" prop="account">
          <el-input v-model="form.account" placeholder="请输入账号" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="form.password"
            placeholder="请输入密码"
            type="password"
          />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-select v-model="form.status" placeholder="请选择状态">
            <el-option :value="1" label="启用" />
            <el-option :value="0" label="禁用" />
          </el-select>
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm">确定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { Delete, Edit, Plus } from "@element-plus/icons-vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { useTokenStore } from "@/stores/token.js";

import {
  userInfoService,
  userdeleteInfoService,
  userAddService,
  userUpdateService,
  userImageUpdateService,
  userPageService,
} from "@/api/user.js";
const tokenStore = useTokenStore();
//图片上传成功的回调函数
const uploadSuccess = (result) => {
  form.value.image = result.data;
};

//搜索
const searchForm = ref({
  name: "",
  phone: "",
  status: 1,
});
// 分页数据
const pagination = ref({
  currentPage: 1,
  pageSize: 4,
  total: 10,
});

const onSearch = () => {
  pagination.value.currentPage = 1; // 搜索时重置到第一页
  userInfuListpage();
};
//重置按钮
const onReset = () => {
  searchForm.value.name = "";
  searchForm.value.phone = "";
  searchForm.value.status = 1;
  pagination.value.currentPage = 1;
  userInfuListpage();
};

// 定义初始表单结构
const initialForm = {
  id: "",
  name: "",
  phone: "",
  account: "",
  password: "",
  status: 1,
  image: "",
};

// 表单和对话框状态
const form = ref({ ...initialForm });
const formRef = ref();
const dialogVisible = ref(false);
const dialogType = ref("");

// 表单验证规则
const rules = {
  name: [{ required: true, message: "请输入姓名", trigger: "blur" }],
  phone: [
    { required: true, message: "请输入电话", trigger: "blur" },
    {
      pattern: /^1[3-9]\d{9}$/,
      message: "请输入正确的手机号",
      trigger: "blur",
    },
  ],
  account: [{ required: true, message: "请输入账号", trigger: "blur" }],
  password: [{ required: true, message: "请输入密码", trigger: "blur" }],
  status: [{ required: true, message: "请选择状态", trigger: "change" }],
};

// 图片上传相关方法
const beforeAvatarUpload = (file) => {
  const isJPG = file.type === "image/jpeg" || file.type === "image/png";
  const isLt2M = file.size / 1024 / 1024 < 2;

  if (!isJPG) {
    ElMessage.error("上传头像图片只能是 JPG/PNG 格式!");
  }
  if (!isLt2M) {
    ElMessage.error("上传头像图片大小不能超过 2MB!");
  }
  return isJPG && isLt2M;
};

const uploadError = (error) => {
  console.error("上传失败:", error);
  ElMessage.error("头像上传失败");
};

// 打开添加对话框
const handleAdd = () => {
  form.value = { ...initialForm };
  dialogType.value = "add";
  dialogVisible.value = true;
};

// 打开编辑对话框
const handleEdit = (row) => {
  form.value = { ...row };
  dialogType.value = "edit";
  dialogVisible.value = true;
};

// 提交表单
const submitForm = () => {
  formRef.value?.validate(async (valid) => {
    if (valid) {
      try {
        if (dialogType.value === "add") {
          await userAddService(form.value);
          ElMessage.success("添加成功");
        } else {
          await userUpdateService(form.value.id, form.value);
          ElMessage.success("修改成功");
        }
        dialogVisible.value = false;
        userInfuList();
      } catch (error) {
        ElMessage.error(dialogType.value === "add" ? "添加失败" : "修改失败");
      }
    }
  });
};

// 分页条件查询方法
const userInfuListpage = async () => {
  try {
    const result = await userPageService(
      pagination.value.currentPage,
      pagination.value.pageSize,
      searchForm.value.name ? searchForm.value.name : null,
      searchForm.value.phone ? searchForm.value.phone : null,
      searchForm.value.status ? searchForm.value.status : null
    );

    tableData.value = result.data.rows;
    pagination.value.total = result.data.total;
  } catch (error) {
    console.error("获取用户列表失败:", error);
    ElMessage.error("获取用户列表失败");
  }
};

const handleSizeChange = (val: number) => {
  pagination.value.pageSize = val;
  userInfuListpage();
};

const handleCurrentChange = (val: number) => {
  pagination.value.currentPage = val;
  userInfuListpage();
};

// 表格数据
const tableData = ref([]);

const userInfuList = async () => {
  try {
    const result = await userInfoService();
    console.log("用户列表数据:", result.data);
    tableData.value = result.data;
  } catch (error) {
    console.error("获取用户列表失败:", error);
    ElMessage.error("获取用户列表失败");
  }
};
//页面加载时调用
onMounted(() => {
  userInfuListpage();
});
// 删除用户
const deleteUser = (row) => {
  ElMessageBox.confirm("确定要删除该用户吗?", "提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  })
    .then(async () => {
      await userdeleteInfoService(row.id);
      ElMessage.success("删除成功");
      userInfuList();
    })
    .catch(() => {
      ElMessage.info("已取消删除");
    });
};
</script>

<style scoped>
.page-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
  padding: 0 10px;
}

.title {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
}

.table-container {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.action-button {
  margin: 0 5px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
  padding: 16px 0;
}

.add-button {
  padding: 12px 20px;
}

:deep(.el-form-item) {
  margin-bottom: 25px;
}

:deep(.el-dialog) {
  padding: 20px;
}

:deep(.el-dialog__body) {
  padding: 20px 40px;
}

:deep(.el-dialog__header) {
  margin-bottom: 10px;
  padding: 20px 40px 0;
}

:deep(.el-dialog__footer) {
  padding: 0 40px 20px;
}

:deep(.el-input),
:deep(.el-select) {
  width: 100%;
}

.avatar-uploader {
  text-align: center;
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 178px;
  height: 178px;
}

.avatar-uploader:hover {
  border-color: #409eff;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.search-form {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
  margin-bottom: 24px;
}
.avatar-preview {
  width: 178px;
  height: 178px;
  display: block;
}
</style>