<template>
  <div class="page-container">
    <!-- 头部 -->
    <div class="header">
      <span class="title">学生管理</span>
      <el-button type="primary" class="add-button" :icon="Plus">
        添加学生
      </el-button>
    </div>
    <!-- 搜索框 -->
    <div class="search-form">
      <el-form :inline="true" :model="searchForm" class="form-content">
        <el-form-item label="姓名">
          <el-input
            v-model="searchForm.name"
            placeholder="请输入姓名"
            clearable
          />
        </el-form-item>
        <el-form-item label="专业">
          <el-input
            v-model="searchForm.major"
            placeholder="请输入专业"
            clearable
          />
        </el-form-item>
        <el-form-item label="班级">
          <el-input
            v-model="searchForm.className"
            placeholder="请输入班级"
            clearable
          />
        </el-form-item>
        <el-form-item label="状态">
          <el-select
            v-model="searchForm.status"
            placeholder="请选择状态"
            clearable
          >
            <el-option label="在校" :value="1" />
            <el-option label="离校" :value="0" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSearch" :icon="Search"
            >搜索</el-button
          >
          <el-button @click="onReset" :icon="Refresh">重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 在表格上方添加按钮组 -->
    <div class="search-buttons">
      <el-button type="primary" @click="showHostelDialog">宿舍查学生</el-button>
      <el-button type="primary" @click="showMinorityDialog"
        >民族查学生</el-button
      >
      <el-button type="primary" @click="showMinorityHostelDialog"
        >民族查宿舍</el-button
      >
    </div>

    <!-- 添加对话框 -->
    <!-- 宿舍查询对话框 -->
    <el-dialog v-model="hostelDialogVisible" title="宿舍查学生" width="30%">
      <el-form>
        <el-form-item label="宿舍">
          <el-select v-model="hostelId" placeholder="请选择宿舍">
            <el-option
              v-for="item in hostelList"
              :key="item.id"
              :label="`${item.buildingName}-${item.roomNumber}`"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="hostelDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="queryByHostel">确定</el-button>
      </template>
    </el-dialog>

    <!-- 民族查询学生对话框-->
    <el-dialog v-model="minorityDialogVisible" title="民族查学生" width="30%">
      <el-form>
        <el-form-item label="民族">
          <el-select v-model="minorityName" placeholder="请选择民族">
            <el-option
              v-for="item in minorityList"
              :key="item.id"
              :label="item.name"
              :value="item.name"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="minorityDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="queryByMinority">确定</el-button>
      </template>
    </el-dialog>

    <!-- 民族查宿舍对话框 -->
    <el-dialog
      v-model="minorityHostelDialogVisible"
      title="民族查宿舍"
      width="30%"
    >
      <el-form>
        <el-form-item label="民族">
          <el-select v-model="minorityName" placeholder="请选择民族">
            <el-option
              v-for="item in minorityList"
              :key="item.id"
              :label="item.name"
              :value="item.name"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="minorityHostelDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="queryHostelByMinority"
          >确定</el-button
        >
      </template>
    </el-dialog>

    <!-- 表格 -->
    <div class="table-container">
      <el-table :data="tableData" stripe border>
         <template v-if="tableData.some((item) => item.name)">
        <el-table-column prop="name" label="姓名" align="center" />
        </template>
        <template v-if="tableData.some((item) => item.age)">
        <el-table-column prop="age" label="年龄" align="center" />
        </template>
        <template v-if="tableData.some((item) => item.gender)">
        <el-table-column prop="gender" label="性别" align="center" />
        </template>
        <template v-if="tableData.some((item) => item.major)">
        <el-table-column prop="major" label="专业" align="center" />
        </template>
  
        <template v-if="tableData.some((item) => item.className)">
          <el-table-column prop="className" label="班级" align="center" />
        </template>
        <template v-if="tableData.some((item) => item.counselor)">
        <el-table-column prop="counselor" label="辅导员" align="center" />
          </template>
        <template v-if="tableData.some((item) => item.admissionDate)">
          <el-table-column
            prop="admissionDate"
            label="入学日期"
            align="center"
          >  
          <!-- 这是因为是 ISO 8601 格式的时间字符串，而前端返回对日期进行格式化处理 -->
          <template #default="scope">
    {{ new Date(scope.row.admissionDate).toLocaleDateString() }}
  </template></el-table-column>
          
        </template>
        <template v-if="tableData.some((item) => item.minority_name)">
          <el-table-column prop="minority_name" label="民族" align="center" />
        </template>
        <template v-if="tableData.some((item) => item.building_name)">
          <el-table-column prop="building_name" label="住宿楼" align="center" />
        </template>
        <template v-if="tableData.some((item) => item.room_number)">
          <el-table-column prop="room_number" label="房间号" align="center" />
        </template>
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="scope">
            <el-tag :type="scope.row.status === 1 ? 'success' : 'info'">
              {{ scope.row.status === 1 ? "在校" : "离校" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="170" fixed="right" align="center">
          <template #default="{ row }">
            <el-button
              type="primary"
              :icon="Edit"
              circle
              class="action-button"
            />
            <el-button
              type="danger"
              @click="deleteUser(row)"
              :icon="Delete"
              circle
              class="action-button"
            />
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 分页 -->
    <div class="pagination-container">
      <el-pagination
        v-model:current-page="pagination.currentPage"
        v-model:page-size="pagination.pageSize"
        :page-sizes="[10, 20, 30, 50]"
        :total="pagination.total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { Search, Refresh, Edit, Delete, Plus } from "@element-plus/icons-vue";
// 控制查询结果对话框的显示

// 搜索
import {
  studentInfoService,
  studentdeleteInfoService,
  queryByHostelService,
  queryByMinorityService,
  queryHostelByMinorityService,
  getHostelListService,
  getMinorityListService,
} from "@/api/student";
import { ElMessage, ElMessageBox } from "element-plus";
// 对话框显示控制
const hostelDialogVisible = ref(false);
const minorityDialogVisible = ref(false);
const minorityHostelDialogVisible = ref(false);

// 选择的值
const hostelId = ref("");
const minorityName = ref("");

// 宿舍和民族列表数据
const hostelList = ref([]);
const minorityList = ref([]);

// 显示对话框方法
const showHostelDialog = () => {
  hostelDialogVisible.value = true;
};
const showMinorityDialog = () => {
  minorityDialogVisible.value = true;
};
const showMinorityHostelDialog = () => {
  minorityHostelDialogVisible.value = true;
};

const tableData = ref([
  {
    name: "",
    age: "",
    gender: "",
    major: "",
    className: "",
    counselor: "",
    admissionDate: "",
    status: "",
    building_name: "",
    minority_name: "",
    room_number: "",
  },
]);
// 在script setup中定义的查询方法
const queryByHostel = async () => {
  try {
    const result = await queryByHostelService(hostelId.value);
    console.log("按宿舍查询结果:", result);
    // 处理返回数据，可能需要调整表格列的显示
    tableData.value = result.data;
    hostelDialogVisible.value = false;
  } catch (error) {
    ElMessage.error("查询失败");
  }
};

const queryByMinority = async () => {
  try {
    const result = await queryByMinorityService(minorityName.value);
    console.log("按民族查询学生结果:", result);
    tableData.value = result.data;
    minorityDialogVisible.value = false;
  } catch (error) {
    ElMessage.error("查询失败");
  }
};

const queryHostelByMinority = async () => {
  try {
    const result = await queryHostelByMinorityService(minorityName.value);
    console.log("按民族查询宿舍结果:", result);
    tableData.value = result.data;
    minorityHostelDialogVisible.value = false;
  } catch (error) {
    ElMessage.error("查询失败");
  }
};
// 需要在初始化时获取宿舍和民族列表数据
const getHostelList = async () => {
  try {
    // 假设有获取宿舍列表的接口
    const result = await getHostelListService();
    hostelList.value = result.data;
  } catch (error) {
    ElMessage.error("获取宿舍列表失败");
  }
};

const getMinorityList = async () => {
  try {
    // 假设有获取民族列表的接口
    const result = await getMinorityListService();
    minorityList.value = result.data;
  } catch (error) {
    ElMessage.error("获取民族列表失败");
  }
};
// 在组件挂载时获取列表数据
onMounted(() => {
  getHostelList();
  getMinorityList();
});

// 搜索表单数据
const searchForm = reactive({
  name: "",
  major: "",
  className: "",
  status: "",
});

// 分页数据
const pagination = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 100,
});

// 表格数据

// 调用查询接口
const studentInfuList = async () => {
  // 拿到后端请求数据
  let resut = await studentInfoService();
  tableData.value = resut.data;
};
studentInfuList();

// 删除学生

const deleteUser = (row) => {
  // 提示弹框
  ElMessageBox.confirm("你确定要删除改用户吗", "温馨提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  })
    .then(async () => {
      let result = await studentdeleteInfoService(row.id);
      ElMessage({
        type: "success",
        message: "删除成功",
      });
      // 刷新列表
      studentInfuList();
    })
    .catch(() => {
      ElMessage({
        type: "info",
        message: "已取消删除",
      });
    });
};

// 方法
const onSearch = () => {
  console.log("搜索", searchForm);
};

const onReset = () => {
  searchForm.name = "";
  searchForm.major = "";
  searchForm.className = "";
  searchForm.status = "";
};

const handleSizeChange = (val: number) => {
  pagination.pageSize = val;
};

const handleCurrentChange = (val: number) => {
  pagination.currentPage = val;
};
</script>


<style scoped>
.page-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
  padding: 0 10px;
}

.title {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
}

.search-form {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
}

.table-container {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}
.search-buttons {
  text-align: center;
  margin-bottom: 10px;
}
.action-button {
  margin: 0 5px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
  padding: 16px 0;
}
</style>
