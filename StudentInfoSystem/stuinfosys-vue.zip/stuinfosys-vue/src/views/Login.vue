<script setup>
import { User, Lock } from "@element-plus/icons-vue";
import { ref } from "vue";
import { ElMessage } from "element-plus";
import { useTokenStore } from "@/stores/token.js";
import { useRouter } from "vue-router";
const router = useRouter();
const tokenStore = useTokenStore();
//控制注册与登录表单的显示， 默认显示注册
const isRegister = ref(false);
//定义数据模型
const registerData = ref({
  account: "",
  password: "",
  rePassword: "",
  name:'',
  phone:''
});

//校验密码的函数
const checkRePassword = (rule, value, callback) => {
  if (value === "") {
    callback(new Error("请再次确认密码"));
  } else if (value !== registerData.value.password) {
    callback(new Error("请确保两次输入的密码一样"));
  } else {
    callback();
  }
};
//定义函数,清空数据模型的数据
const cRegisterData = () => {
  registerData.value = {
    username: "",
    password: "",
    rePassword: "",
    name:'',
    phone:''
  };
};

const rules = {
  account: [
    { required: true, message: "请输入账号名", trigger: "blur" },
    { min: 5, max: 16, message: "长度为5~16位非空字符", trigger: "blur" },
  ],
  password: [
    { required: true, message: "请输入密码", trigger: "blur" },
    { min: 5, max: 16, message: "长度为5~16位非空字符", trigger: "blur" },
  ],
  name: [{ required: true, message: "请输入姓名", trigger: "blur" }],
  phone: [
    { required: true, message: "请输入电话", trigger: "blur" },
    {
      pattern: /^1[3-9]\d{9}$/,
      message: "请输入正确的手机号",
      trigger: "blur",
    },
  ],
  rePassword: [{ validator: checkRePassword, trigger: "blur" }],
};

//调用后台接口,完成注册
import { userAddService, userLoginService } from "@/api/user.js";
// 获取表单引用
const form = ref();

// 修改注册方法
const register = async () => {
  // 先进行表单校验
  await form.value.validate(async (valid) => {
    if (valid) {
      // 校验通过才调用注册接口
      try {
        let result = await userAddService(registerData.value);
        ElMessage.success("注册成功");
        // 注册成功后切换到登录页面
        isRegister.value = false;
        cRegisterData();
      } catch (error) {
        ElMessage.error("注册失败");
      }
    } else {
      ElMessage.error("请正确填写注册信息");
      return false;
    }
  });
};

//绑定数据,复用注册表单的数据模型
//表单数据校验
//登录函数


// 添加登陆校验规则
const login = async () => {
  await form.value.validate(async (valid) => {
    if (valid) {
      try {
        let result = await userLoginService(registerData.value);
        ElMessage.success("登录成功");
        tokenStore.setToken(result.data);
        router.push("/");
      } catch (error) {
        ElMessage.error("登录失败");
      }
    } else {
      ElMessage.error("请正确填写登录信息");
      return false;
    }
  });
};
</script>

<template>
  <div class="login-container">
    <div class="login-box">
      <!-- 左侧插画 -->
      <div class="login-left">            <div class="content">
          <h2>学生信息管理系统</h2>
          <p>Welcome to Student Management System</p>
        </div>  </div>
      
      <!-- 右侧表单 -->
      <div class="login-form">
        <!-- 注册表单 -->
        <el-form
          ref="form"
          size="large"
          v-if="isRegister"
          :model="registerData"
          :rules="rules"
        >
          <h2 class="title">注册账号</h2>
          
          <el-form-item prop="account">
            <el-input
              :prefix-icon="User"
              placeholder="请输入账号"
              v-model="registerData.account"
            />
          </el-form-item>

          <el-form-item prop="phone">
            <el-input
              :prefix-icon="User" 
              placeholder="请输入手机号"
              v-model="registerData.phone"
            />
          </el-form-item>

          <el-form-item prop="name">
            <el-input
              :prefix-icon="User"
              placeholder="请输入姓名"
              v-model="registerData.name"
            />
          </el-form-item>

          <el-form-item prop="password">
            <el-input
              :prefix-icon="Lock"
              type="password" 
              placeholder="请输入密码"
              v-model="registerData.password"
            />
          </el-form-item>

          <el-form-item prop="rePassword">
            <el-input
              :prefix-icon="Lock"
              type="password"
              placeholder="请确认密码" 
              v-model="registerData.rePassword"
            />
          </el-form-item>

          <el-form-item>
            <el-button type="primary" class="submit-btn" @click="register">
              注册
            </el-button>
          </el-form-item>

          <div class="form-footer">
            <span>已有账号?</span>
            <el-link type="primary" @click="isRegister = false; cRegisterData()">
              去登录
            </el-link>
          </div>
        </el-form>

        <!-- 登录表单 -->
        <el-form
          ref="form"
          size="large" 
          v-else
          :model="registerData"
          :rules="rules"
        >
          <h2 class="title">欢迎登录</h2>
         

          <el-form-item prop="account">
            <el-input
              :prefix-icon="User"
              placeholder="请输入账号"
              v-model="registerData.account"
            />
          </el-form-item>

          <el-form-item prop="password">
            <el-input
              :prefix-icon="Lock"
              type="password"
              placeholder="请输入密码"
              v-model="registerData.password" 
            />
          </el-form-item>

          <div class="remember-forgot">
            <el-checkbox v-model="rememberMe">记住我</el-checkbox>
            <el-link type="primary">忘记密码?</el-link>
          </div>

          <el-form-item>
            <el-button type="primary" class="submit-btn" @click="login">
              登录
            </el-button>
          </el-form-item>

          <div class="form-footer">
            <span>没有账号?</span>
            <el-link type="primary" @click="isRegister = true; cRegisterData()">
              立即注册
            </el-link>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.login-container {
  height: 100vh;
  background-color: #f5f7f9;
  display: flex;
  align-items: center;
  justify-content: center;

  .login-box {
    width: 1000px;
    height: 600px;
    background-color: white;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    display: flex;
    overflow: hidden;

    .login-left {
      color: #f5f7f9;
      flex: 1;
      background: linear-gradient(145deg, #67c23a, #95d475);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 40px;

   .content {
        text-align: center;

        h2 {
          font-size: 28px;
          font-weight: 600;
          margin-bottom: 20px;
        }
    }
    }

    .login-form {
      width: 400px;
      padding: 40px;
      
      .title {
        font-size: 28px;
        font-weight: 600;
        color:#67c10a;
        margin-bottom: 8px;
        text-align: center;
        margin-bottom: 40px;
      }



      :deep(.el-input) {
        .el-input__wrapper {
          box-shadow: 0 0 0 1px #dcdfe6 inset;
          
          &:hover {
            box-shadow: 0 0 0 1px #67c23a inset;
          }
          
          &.is-focus {
            box-shadow: 0 0 0 1px #67c23a inset;
          }
        }
      }

      .submit-btn {
        width: 100%;
        height: 44px;
        border-radius: 22px;
        font-size: 16px;
        margin-top: 20px;
      }

      .remember-forgot {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: -10px 0 10px;
      }

      .form-footer {
        text-align: center;
        margin-top: 20px;
        color: #999;

        .el-link {
          margin-left: 8px;
        }
      }
    }
  }
}
</style>