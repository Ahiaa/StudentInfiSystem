<template>
  <div class="page-container">
    <!-- 头部 -->
    <div class="header">
      <span class="title">班级管理</span>
      <el-button type="primary" class="add-button" :icon="Plus">
        添加班级
      </el-button>
    </div>

    <!-- 搜索框 -->
    <div class="search-form">
      <el-form :inline="true" :model="searchForm" class="form-content">
        <el-form-item label="年级">
          <el-input v-model="searchForm.grade" placeholder="请输入年级" clearable />
        </el-form-item>
        <el-form-item label="专业">
          <el-input v-model="searchForm.major" placeholder="请输入专业" clearable />
        </el-form-item>
        <el-form-item label="辅导员">
          <el-input v-model="searchForm.counselor" placeholder="请输入辅导员" clearable />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSearch" :icon="Search">搜索</el-button>
          <el-button @click="onReset" :icon="Refresh">重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 表格 -->
    <div class="table-container">
      <el-table :data="tableData" stripe border>
        <el-table-column prop="grade" label="年级" />
        <el-table-column prop="major" label="专业" />
        <el-table-column prop="counselor" label="辅导员" />
        <el-table-column label="操作" width="170">
          <template #default>
            <el-button type="primary" :icon="Edit" circle class="action-button"/>
            <el-button type="danger" :icon="Delete" circle class="action-button"/>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 分页 -->
    <div class="pagination-container">
      <el-pagination
        v-model:current-page="pagination.currentPage"
        v-model:page-size="pagination.pageSize"
        :page-sizes="[10, 20, 30, 50]"
        :total="pagination.total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { Search, Refresh, Edit, Delete, Plus } from '@element-plus/icons-vue'

// 搜索表单数据
const searchForm = reactive({
  grade: '',
  major: '',
  counselor: ''
})

// 分页数据
const pagination = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 100
})

// 表格数据
const tableData = ref([
  {
    grade: '2020',
    major: '计算机科学',
    counselor: '李老师'
  }
  // ... 更多数据
])

// 方法
const onSearch = () => {
  console.log('搜索', searchForm)
}

const onReset = () => {
  searchForm.grade = ''
  searchForm.major = ''
  searchForm.counselor = ''
}

const handleSizeChange = (val: number) => {
  pagination.pageSize = val
}

const handleCurrentChange = (val: number) => {
  pagination.currentPage = val
}
</script>

<style scoped>
/* 样式与用户管理页面相同 */
.page-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
  padding: 0 10px;
}

.title {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
}

.search-form {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
  margin-bottom: 24px;
}

.table-container {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
}

.action-button {
  margin: 0 5px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
  padding: 16px 0;
}
</style>