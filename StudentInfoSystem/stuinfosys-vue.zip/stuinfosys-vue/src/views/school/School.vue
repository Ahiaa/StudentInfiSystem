<template>
  <div class="page-container">
    <!-- 头部 -->
    <div class="header">
      <span class="title">学校管理</span>
      <el-button type="primary" class="add-button" :icon="Plus">
        添加学校
      </el-button>
    </div>

    <!-- 搜索框 -->
    <div class="search-form">
      <el-form :inline="true" :model="searchForm" class="form-content">
        <el-form-item label="学校名称">
          <el-input v-model="searchForm.name" placeholder="请输入学校名称" clearable />
        </el-form-item>
        <el-form-item label="创建日期">
          <el-date-picker
            v-model="searchForm.foundingDate"
            type="date"
            placeholder="选择日期"
            clearable
          />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="searchForm.status" placeholder="请选择状态" clearable>
            <el-option label="启用" :value="1" />
            <el-option label="禁用" :value="0" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSearch" :icon="Search">搜索</el-button>
          <el-button @click="onReset" :icon="Refresh">重置</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 表格 -->
    <div class="table-container">
      <el-table :data="tableData" stripe border>
        <el-table-column prop="name" label="学校名称" />
        <el-table-column prop="founding_date" label="创建日期" />
        <el-table-column prop="address" label="地址" show-overflow-tooltip />
        <el-table-column prop="contact" label="联系方式" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 1 ? 'success' : 'danger'">
              {{ scope.row.status === 1 ? '启用' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="170" fixed="right">
          <template #default>
            <el-button type="primary" :icon="Edit" circle class="action-button"/>
            <el-button type="danger" :icon="Delete" circle class="action-button"/>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 分页 -->
    <div class="pagination-container">
      <el-pagination
        v-model:current-page="pagination.currentPage"
        v-model:page-size="pagination.pageSize"
        :page-sizes="[10, 20, 30, 50]"
        :total="pagination.total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
  </div>

</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { Search, Refresh, Edit, Delete, Plus } from '@element-plus/icons-vue'

// 搜索表单数据
const searchForm = reactive({
  name: '',
  foundingDate: '',
  status: ''
})

// 分页数据
const pagination = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 100
})

// 表格数据
const tableData = ref([
  {
    name: '北京科技大学',
    founding_date: '1988-09-01',
    address: '北京市海淀区',
    contact: '010-88888888',
    status: 1
  },
  // ... 更多数据
])

// 方法
const onSearch = () => {
  console.log('搜索', searchForm)
}

const onReset = () => {
  searchForm.name = ''
  searchForm.foundingDate = ''
  searchForm.status = ''
}

const handleSizeChange = (val: number) => {
  pagination.pageSize = val
}

const handleCurrentChange = (val: number) => {
  pagination.currentPage = val
}
</script>

<style scoped>
/* 样式与用户管理页面相同 */
.page-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
  padding: 0 10px;
}

.title {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
}

.search-form {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
  margin-bottom: 24px;
}

.table-container {
  background-color: #fff;
  padding: 24px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
}

.action-button {
  margin: 0 5px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
  padding: 16px 0;
}
</style>