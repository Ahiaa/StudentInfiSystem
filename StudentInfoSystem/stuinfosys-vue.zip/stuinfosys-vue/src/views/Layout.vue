<template>
  <el-container class="layout-container-demo" style="height: 750px">
    <!-- 左侧菜单 -->
    <el-aside width="200px" class="no-scrollbar">
      <el-scrollbar class="dist">
        <el-menu router>
          <el-menu-item index="/user">
            <el-icon>
              <Message />
            </el-icon>
            <span>用户管理</span>
          </el-menu-item>

          <el-menu-item index="/student">
            <el-icon>
              <Message />
            </el-icon>
            <span>学生管理</span>
          </el-menu-item>

          <el-menu-item index="/teacher">
            <el-icon>
              <Message />
            </el-icon>
            <span>教师管理</span>
          </el-menu-item>

          <el-menu-item index="/class">
            <el-icon>
              <Message />
            </el-icon>
            <span>班级管理</span>
          </el-menu-item>

          <el-menu-item index="/school">
            <el-icon>
              <Message />
            </el-icon>
            <span>学校管理</span>
          </el-menu-item>

          <el-sub-menu index="1">
            <template #title>
              <el-icon><message /></el-icon>用户中心
            </template>
            <el-menu-item index="avatar">更多</el-menu-item>
          </el-sub-menu>
        </el-menu>
      </el-scrollbar>
    </el-aside>

    <!-- 右侧内容区域 -->
    <el-container>
      <el-header style="text-align: right; font-size: 12px">
        <div class="toolbar">
          <div class="system-title">学生信息管理系统</div>
          <el-dropdown @command="handleLogout">
            <span class="el-dropdown__box">
              <el-avatar
                src="https://big-001event.oss-cn-beijing.aliyuncs.com/7a0c69d2-84a5-45a1-8ce2-801ab1b98a76.jpg"
              />
              <el-icon>
                <CaretBottom />
              </el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="logout" :icon="SwitchButton"
                  >退出登陆</el-dropdown-item
                >
                <el-dropdown-item command="avatar" :icon="Crop"
                  >更多</el-dropdown-item
                >
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- Main Content (去除滚动条) -->
      <el-main class="no-scrollbar">
        <router-view />
        <!-- 页面内容 -->
      </el-main>
    </el-container>
  </el-container>
</template>

<script lang="ts" setup>
import { useRouter } from "vue-router";
const router = useRouter();

import { useTokenStore } from "@/stores/token.js";
import { ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Menu as IconMenu,
  Message,
  Setting,
  SwitchButton,
  CaretBottom,
  Crop,
} from "@element-plus/icons-vue";

const item = {
  date: "2016-05-02",
  name: "Tom",
  address: "No. 189, Grove St, Los Angeles",
};

const tableData = ref(Array.from({ length: 20 }).fill(item));

// 处理退出操作
const handleLogout = (command) => {
  // 清除token
  //判断指令
  if (command === "logout") {
    const tokenStore = useTokenStore();
    //退出登录
    ElMessageBox.confirm("您确认要退出吗?", "温馨提示", {
      confirmButtonText: "确认",
      cancelButtonText: "取消",
      type: "warning",
    })
      .then(async () => {
        //退出登录
        //1.清空pinia中存储的token以及个人信息
        tokenStore.removeToken();

        //2.跳转到登录页面
        router.push("/login");
        ElMessage({
          type: "success",
          message: "退出登录成功",
        });
      })
      .catch(() => {
        ElMessage({
          type: "info",
          message: "您取消了退出登录",
        });
      });
  } else {
    //路由
    router.push("/" + command);
  }
};
</script>

<style scoped lang=scss>
.layout-container-demo .el-header {
  position: relative;
  background-color: var(--el-color-primary-light-7);
  color: var(--el-text-color-primary);
}

.layout-container-demo .el-aside {
  color: var(--el-text-color-primary); 
   background: var(--el-color-primary-light-8);
  /* background:linear-gradient(145deg, #67c23a, #95d475) */
}

.layout-container-demo .el-menu {
  border-right: none;
}

.layout-container-demo .el-main {
  padding: 0;
  overflow: auto; /* 去除滚动条hidden */
}

.layout-container-demo .toolbar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  right: 20px;
}
.el-dropdown__box {
  display: flex;
  align-items: center;

  .el-icon {
    color: #999;
    margin-left: 10px;
  }

  &:active,
  &:focus {
    outline: none;
  }
}
.no-scrollbar {
  overflow: hidden; /* 去除滚动条 */
}
.dist {
  margin-top: 60px;
}
/*  */
.layout-container-demo .toolbar {
  display: flex;
}

.system-title {
  font-size: 24px;
  font-weight: bold;
  color:#67c10a;
  flex-grow: 1;
  text-align: center;
}


</style>
