import { createRouter, createWebHistory } from 'vue-router'
import Layout from '@/views/Layout.vue'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      component: () => import('@/views/Login.vue')
    },
    {
      path: '/',
      component: Layout,
      redirect:'/user',
      children: [
        {
          path: 'user',
          component: () => import('@/views/user/User.vue'),
        },
        {
          path: 'student',
          component: () => import('@/views/student/Student.vue')
        },
        {
          path: 'teacher', 
          component: () => import('@/views/teacher/Teacher.vue')
        },
        {
          path: 'class',
          component: () => import('@/views/classes/Classes.vue')
        },
        {
          path: 'school',
          component: () => import('@/views/school/School.vue')
        },
        {
          path: 'avatar',  // 确保 avatar 路由正确配置
          component: () => import('@/views/user/UserAvtar.vue')  // 修正路径
        }
      ]
    }
  ],
})
export default router
