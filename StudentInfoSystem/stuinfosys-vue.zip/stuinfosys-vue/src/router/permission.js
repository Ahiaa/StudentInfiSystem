import router from '@/router/index'
import { useTokenStore } from '@/stores/token.js'

// 定义不需要登录就可以访问的白名单路由
const whiteList = ['/login', '/register']

// 全局前置守卫
router.beforeEach((to, from, next) => {
  const tokenStore = useTokenStore()
  // 有token
  if (tokenStore.token) {
    if (to.path === '/login') {
      // 如果已登录，但访问登录页面，则重定向到首页
      next({ path: '/' })
    } else {
      next() // 正常放行
    }
  } 
  // 无token
  else {
    if (whiteList.includes(to.path)) {
      // 未登录可以访问白名单页面
      next()
    } else {
      // 其他页面重定向到登录页
      next('/login')
    }
  }
})

// // 全局后置守卫
// router.afterEach((to, from) => {
//   // 可以在这里修改页面标题
//   document.title = to.meta.title || 'Your Default Title'
// })