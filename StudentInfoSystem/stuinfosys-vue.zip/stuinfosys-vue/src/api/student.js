import request from '@/utils/request.js'
//查询学生
export const studentInfoService = ()=>{
    return request.get('/students')
}
// 删除学生
export const studentdeleteInfoService = (id)=>{
    // return request.delete('/users?id='+id)
    return request.delete(`/students/${id}`);
}
// 按宿舍查询学生
export const queryByHostelService = (hostelId) => {
    return request.get(`/students/queryByHostel/${hostelId}`)
  }
  
  // 按民族查询学生
  export const queryByMinorityService = (minorityName) => {
    return request.get(`/students/queryByMinority/${encodeURIComponent(minorityName)}`)

  }
  
  // 按民族查询宿舍
  export const queryHostelByMinorityService = (minorityName) => {
    return request.get(`/students/queryHostelByMinority/${encodeURIComponent(minorityName)}`)
  }

  export const getHostelListService = () => {
    return request.get(`/students/hostelList`)

  }
  
  // 获取民族列表
  export const getMinorityListService = () => {
    return request.get(
     `/students/minorityList`
    )
  }