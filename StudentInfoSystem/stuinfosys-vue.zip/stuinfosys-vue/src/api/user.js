//导入request.js请求工具
import request from '@/utils/request.js'

//提供调用登录接口的函数
// 将liginData登陆数据传递到后端
export const userLoginService = (loginData)=>{
    // 使用 URLSearchParams 的方式（注释部分将数据转换为 URL 编码的表单格式 (Content-Type: application/x-www-form-urlencoded)
//数据格式如：username=admin&password=123456
    // const params = new URLSearchParams();
    // for(let key in loginData){
    //     params.append(key,loginData[key])
    // }
    return request.post('/users/login',loginData)
}


//获取用户详细信息
export const userInfoService = ()=>{
    return request.get('/users')
}


//修改个人信息
export const userInfoUpdateService = (userInfoData)=>{
   return request.put('/users/${id}',userInfoData)
}

// 用户信息删除
export const userdeleteInfoService = (id)=>{
    // return request.delete('/users?id='+id)
    return request.delete(`/users/${id}`);
}


// 添加用户
export const userAddService = (data) => {
    return request.post('/users/register', data)
  }
  
  // 更新用户
  export const userUpdateService = (id,data) => {
    return request.put(`/users/${id}`,data)
  }

//修改头像
export const userImageUpdateService = (aimageUrl)=>{
    const params = new URLSearchParams();
    params.append('aimageUrl',aimageUrl)
    return request.post('/upload',params)
}
// // 分页查询
// export const userPageService = (currentPage, pageSize) => {
//     return request.get(`/users/page?currentPage=${currentPage}&pageSize=${pageSize}`);
// }
// 分页查询 
// 使用 params 参数
export const userPageService = (currentPage, pageSize, name, phone, status) => {
    return request.get('/users/page', {
      params: {
        currentPage,
        pageSize,
        name,
        phone,
        status
      }
    });
  };