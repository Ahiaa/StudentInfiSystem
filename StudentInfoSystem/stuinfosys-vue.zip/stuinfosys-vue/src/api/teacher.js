import request from '@/utils/request.js'
//查询老师
export const teachersInfuList = ()=>{
    return request.get('/teachers')
}
// 删除老师
export const teacherdeleteInfoService = (id)=>{
    // return request.delete('/users?id='+id)
    return request.delete(`/teachers/${id}`);
}